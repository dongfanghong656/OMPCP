# Pro Review Entry: Sphere-only Mie（米氏） Full-NA（全数值孔径） Branch（分支） + CI（持续集成） Evidence（证据）

## Review target（审查目标）

This packet（审查包） asks Pro（审阅方） to review whether the exact-sphere route is now correctly separated from the non-spherical T-matrix（T矩阵） backend（后端） path.

Main runtime（运行时） contract（合同） for exact homogeneous spheres:

```text
mode = full_na
eps = 0
ideal = false
force_tmatrix = false
sphere_mie_used = true
tmatrix_used = false
tmatrix_backend_required = false
scattering_branch = sphere_mie_full_na
lateral_response_model = sphere_mie_angle_resolved_pupil_field
particle_lateral_scattering_enters_profile = true
```

## What changed（修改内容）

- Added `physics/mie_sphere.py` for pure Mie（米氏） `S1/S2` kernel（核） and backscatter（后向散射） convention（约定） checks.
- Added `physics/sphere_mie_pupil.py` for angle-resolved pupil（光瞳） field（场） construction.
- Updated `scripts/oct_nonspherical_psf_solver.py` so exact spheres use `sphere_mie_full_na` instead of requiring T-matrix（T矩阵）.
- Added `scripts/sphere_particle_sweep_runner.py` as a sphere-only full-NA（全数值孔径） sweep（扫描） runner（运行器）.
- Added `tests/test_sphere_mie_branch_contract.py` for branch routing（分支路由） and Mie（米氏） contract（合同） tests.
- Updated schema（模式） / known-limits（已知限制） docs（文档） and CI（持续集成） workflow（工作流）.

## Verification（验证）

Local verification（本地验证） already run:

```text
python -m unittest discover -s tests -p test_sphere_mie_branch_contract.py  -> 5 tests OK
python 12_test_low_na_asymptotic_helpers.py                                -> 82 tests OK
python scripts/validate_oct_nonspherical_psf_solver.py ...                  -> exit 0
python scripts/sphere_particle_sweep_runner.py --diameters 200,500,1000 ... -> 3/3 cases OK
```

GitHub Actions（GitHub持续集成） verification（验证）:

```text
run_id = 25053221805
head_sha = 3355e6e973c7cecc1f2367526805176f66f95d76
conclusion = success
url = https://github.com/dongfanghong656/OMPCP/actions/runs/25053221805
```

The CI（持续集成） artifact（产物） was imported into canonical reports（标准报告） with `scripts/import_ci_evidence_artifacts.py`; see `evidence/round6p1_ci_evidence_import_manifest.*`.

## Evidence（证据） contents（内容）

- `evidence/`: CPython 3.10（解释器3.10） + T-matrix（T矩阵） imported evidence（导入证据）, validation（验证）, measurement（测量）, and backend（后端） provenance（来源）.
- `sphere_mie/acceptance/`: local 3-case exact sphere Mie（球形米氏） full-NA（全数值孔径） acceptance（验收） sweep（扫描） for 200/500/1000 nm.
- `sphere_mie/ci_smoke/`: CI（持续集成） smoke（烟测） sphere branch（球形分支） outputs.
- `code/`: key changed code（代码） and workflow（工作流） files.
- `docs/`: schema（模式） and known-limits（已知限制） updates.

## Known limits（已知限制）

- This is still scalar fixed-basis（标量固定基底） full-NA（全数值孔径） modeling, not full vector Debye（矢量德拜） or calibrated instrument-level OCT（光学相干断层扫描） truth.
- It closes the exact-sphere branch（精确球形分支） only; non-spherical particles（非球形粒子） still need compatible T-matrix（T矩阵） backend（后端） evidence（证据）.
- The low-NA separable baseline（低数值孔径可分离基线） still uses Gaussian lateral（高斯横向） surrogate（替代模型） and must not be interpreted as particle-aware lateral PSF（粒子感知横向点扩散函数） evidence（证据）.
- The 3-case acceptance（验收） sweep（扫描） is a contract（合同） / smoke（烟测） packet（审查包）; it is not a final paper-safe（论文可用） particle-size conclusion.
